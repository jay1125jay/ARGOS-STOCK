import os
import time
from datetime import datetime

from engines.stock.providers.adapters.kis_adapter import KISAdapter
from engines.stock.indicator_engine import run as run_indicator
from engines.stock.technical_ai import run as run_technical
from engines.stock.ranking_engine import run as run_ranking

from engines.stock.news_ai import run as run_news
from engines.stock.disclosure_ai import run as run_disclosure
from engines.stock.money_flow_ai import run as run_money_flow
from engines.stock.sector_ai import run as run_sector
from engines.stock.market_state_ai import run as run_market
from engines.stock.macro_ai import run as run_macro
from engines.stock.us_ai import run as run_us
from engines.stock.earnings_ai import run as run_earnings
from engines.stock.risk_ai import run as run_risk

from engines.stock.chief_ai import ChiefAI
from engines.stock.decision_center import DecisionCenter
from engines.stock.execution_ai import ExecutionAI
from engines.stock.trade_history_engine import TradeHistoryEngine
from engines.stock.portfolio_engine import PortfolioEngine
from engines.stock.pnl_engine import PnLEngine
from engines.stock.learning_engine import LearningEngine
from engines.stock.learning_ai import run as run_learning
from engines.stock.report_ai import ReportAI

from engines.stock.core.process_lock import ProcessLock
from engines.stock.core.safe_json import SafeJSON


ROOT = r"C:\ARGOS_STOCK"

STATUS = os.path.join(
    ROOT,
    "data",
    "runner",
    "auto_runner_status.json"
)

STOP_FILE = os.path.join(
    ROOT,
    "data",
    "runner",
    "auto_runner_stop.flag"
)

SLEEP_SECONDS = 5


class AutoRunner:

    def now(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def save_status(self, data):
        SafeJSON.save(STATUS, data)

    def should_stop(self):
        return os.path.exists(STOP_FILE)

    def clear_stop(self):
        if os.path.exists(STOP_FILE):
            os.remove(STOP_FILE)

    def request_stop(self):
        os.makedirs(
            os.path.dirname(STOP_FILE),
            exist_ok=True
        )

        with open(
            STOP_FILE,
            "w",
            encoding="utf-8"
        ) as f:
            f.write("STOP")

    def run_once(self, loop_count=1):

        steps = []

        def step(name, fn):
            try:
                result = fn()

                steps.append({
                    "step": name,
                    "status": (
                        result.get("status", "DONE")
                        if isinstance(result, dict)
                        else "DONE"
                    )
                })

                return result if isinstance(result, dict) else {}

            except Exception as e:
                steps.append({
                    "step": name,
                    "status": "ERROR",
                    "error": str(e)
                })

                return {}

        # 데이터 및 분석
        step("KIS", lambda: KISAdapter().connect())

        indicator = step(
            "INDICATOR",
            run_indicator
        )

        technical = step(
            "TECHNICAL",
            run_technical
        )

        ranking = step(
            "RANKING",
            run_ranking
        )

        step("NEWS", run_news)
        step("DISCLOSURE", run_disclosure)
        step("MONEY_FLOW", run_money_flow)
        step("SECTOR", run_sector)
        step("MARKET", run_market)
        step("MACRO", run_macro)
        step("US", run_us)
        step("EARNINGS", run_earnings)
        step("RISK", run_risk)

        # 판단 및 실행
        chief = step(
            "CHIEF",
            lambda: ChiefAI().decide()
        )

        decision = step(
            "DECISION",
            lambda: DecisionCenter().evaluate(chief)
        )

        execution = step(
            "EXECUTION",
            lambda: ExecutionAI().run()
        )

        # 실행 이후 실제 저장된 포트폴리오를 다시 읽는다.
        portfolio_engine = PortfolioEngine()

        portfolio_status = {
            "engine": "portfolio_engine",
            "status": "READY",
            "account": portfolio_engine.get_account(),
            "positions": portfolio_engine.get_positions(),
            "position_count": len(
                portfolio_engine.get_positions()
            )
        }

        # 기록 및 손익
        history = step(
            "TRADE_HISTORY",
            lambda: TradeHistoryEngine().run()
        )

        pnl = step(
            "PNL",
            lambda: PnLEngine().run()
        )

        learning_engine = step(
            "LEARNING_ENGINE",
            lambda: LearningEngine().run()
        )

        report = step(
            "REPORT",
            lambda: ReportAI().run()
        )

        step(
            "LEARNING",
            run_learning
        )

        symbol = decision.get("symbol", "")
        price = float(
            decision.get("price", 0) or 0
        )
        signal = decision.get("signal", "WAIT")

        status = {
            "project": "ARGOS_STOCK",
            "engine": "auto_runner",
            "mode": "PAPER_ONLY",
            "running": True,
            "loop_count": loop_count,

            "final_signal": signal,
            "symbol": symbol,
            "price": price,
            "symbol_score": decision.get(
                "symbol_score",
                0
            ),
            "symbol_reason": decision.get(
                "symbol_reason",
                ""
            ),
            "decision_score": decision.get(
                "score",
                0
            ),

            "execution_action": execution.get(
                "action",
                "NO_ACTION"
            ),

            "positions": portfolio_status.get(
                "position_count",
                0
            ),

            "technical_status": technical.get(
                "status",
                "UNKNOWN"
            ),
            "technical_valid": technical.get(
                "valid_count",
                0
            ),
            "ranking_best": ranking.get(
                "best",
                {}
            ),
            "indicator_count": indicator.get(
                "count",
                0
            ),

            "portfolio": portfolio_status,
            "history": history,
            "total_trades": history.get(
                "total_trades",
                0
            ),
            "pnl": pnl,
            "learning": learning_engine,

            "report_signal": report.get(
                "final_signal",
                "WAIT"
            ),
            "report_score": report.get(
                "total_score",
                0
            ),

            "steps": steps,
            "updated_at": self.now()
        }

        self.save_status(status)

        print("=" * 60)
        print("ARGOS STOCK AUTO RUNNER")
        print("MODE : PAPER_ONLY")
        print("-" * 60)
        print("LOOP :", loop_count)
        print("FINAL :", status["final_signal"])
        print("SYMBOL :", status["symbol"])
        print("PRICE :", status["price"])
        print("SCORE :", status["decision_score"])
        print("ACTION :", status["execution_action"])
        print("POSITION :", status["positions"])
        print(
            "TRADES :",
            history.get("total_trades", 0)
        )
        print(
            "PNL :",
            pnl.get("total_pnl", 0)
        )
        print("=" * 60)

        return status

    def start(self):

        lock = ProcessLock()

        if not lock.acquire():
            print("AUTO_RUNNER_ALREADY_RUNNING")
            return

        self.clear_stop()

        loop_count = 0

        try:
            while True:

                if self.should_stop():
                    break

                loop_count += 1

                self.run_once(loop_count)

                time.sleep(SLEEP_SECONDS)

        finally:
            lock.release()

            try:
                status = SafeJSON.load(
                    STATUS,
                    {}
                )

                status["running"] = False
                status["stopped_at"] = self.now()

                self.save_status(status)

            except Exception:
                self.save_status({
                    "project": "ARGOS_STOCK",
                    "engine": "auto_runner",
                    "mode": "PAPER_ONLY",
                    "running": False,
                    "stopped_at": self.now()
                })

            print("AUTO_RUNNER_STOPPED")


def start():
    AutoRunner().start()


def stop():
    AutoRunner().request_stop()
    print("AUTO_RUNNER_STOP_REQUESTED")


if __name__ == "__main__":
    start()